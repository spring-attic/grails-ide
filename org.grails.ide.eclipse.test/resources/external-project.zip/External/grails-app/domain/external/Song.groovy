package external

class Song {

    static constraints = {
    }
}
