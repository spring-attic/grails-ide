package gtunez

class SongController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]

    def index = {
        redirect(action: "list", params: params)
    }

    def list = {
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [bananaInstanceList: Song.list(params), bananaInstanceTotal: Song.count()]
    }

    def create = {
        def bananaInstance = new Song()
        bananaInstance.properties = params
        return [bananaInstance: bananaInstance]
    }

    def save = {
        def bananaInstance = new Song(params)
        if (bananaInstance.save(flush: true)) {
            flash.message = "${message(code: 'default.created.message', args: [message(code: 'banana.label', default: 'Banana'), bananaInstance.id])}"
            redirect(action: "show", id: bananaInstance.id)
        }
        else {
            render(view: "create", model: [bananaInstance: bananaInstance])
        }
    }

    def show = {
        def bananaInstance = Song.get(params.id)
        if (!bananaInstance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'banana.label', default: 'Banana'), params.id])}"
            redirect(action: "list")
        }
        else {
            [bananaInstance: bananaInstance]
        }
    }

    def edit = {
        def bananaInstance = Song.get(params.id)
        if (!bananaInstance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'banana.label', default: 'Banana'), params.id])}"
            redirect(action: "list")
        }
        else {
            return [bananaInstance: bananaInstance]
        }
    }

    def update = {
        def bananaInstance = Song.get(params.id)
        if (bananaInstance) {
            if (params.version) {
                def version = params.version.toLong()
                if (bananaInstance.version > version) {
                    
                    bananaInstance.errors.rejectValue("version", "default.optimistic.locking.failure", [message(code: 'banana.label', default: 'Banana')] as Object[], "Another user has updated this Banana while you were editing")
                    render(view: "edit", model: [bananaInstance: bananaInstance])
                    return
                }
            }
            bananaInstance.properties = params
            if (!bananaInstance.hasErrors() && bananaInstance.save(flush: true)) {
                flash.message = "${message(code: 'default.updated.message', args: [message(code: 'banana.label', default: 'Banana'), bananaInstance.id])}"
                redirect(action: "show", id: bananaInstance.id)
            }
            else {
                render(view: "edit", model: [bananaInstance: bananaInstance])
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'banana.label', default: 'Banana'), params.id])}"
            redirect(action: "list")
        }
    }

    def delete = {
        def bananaInstance = Song.get(params.id)
        if (bananaInstance) {
            try {
                bananaInstance.delete(flush: true)
                flash.message = "${message(code: 'default.deleted.message', args: [message(code: 'banana.label', default: 'Banana'), params.id])}"
                redirect(action: "list")
            }
            catch (org.springframework.dao.DataIntegrityViolationException e) {
                flash.message = "${message(code: 'default.not.deleted.message', args: [message(code: 'banana.label', default: 'Banana'), params.id])}"
                redirect(action: "show", id: params.id)
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'banana.label', default: 'Banana'), params.id])}"
            redirect(action: "list")
        }
    }
}
