package gtunes

class SongController {
    def scaffold = Song
}
