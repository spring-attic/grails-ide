package gtunez



import grails.test.mixin.*
import org.junit.*

/**
 * See the API for {@link grails.test.mixin.services.ServiceUnitTestMixin} for usage instructions
 */
@TestFor(SongService)
class SongServiceTests {

    void testSomething() {
        fail "Implement me"
    }
}
