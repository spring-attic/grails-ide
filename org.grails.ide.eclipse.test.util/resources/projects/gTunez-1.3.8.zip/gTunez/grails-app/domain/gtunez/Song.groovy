package gtunez

class Song {
	
	static Song example = null
	static SongController myController
	
	def songService
	
    static constraints = {
    }
	
	String title
	String genre
	
	def play() {
		songService.play(this)
	} 
}
