package sample.contact

import org.springframework.security.acls.domain.BasePermission
import org.springframework.security.acls.domain.PrincipalSid
import org.springframework.security.acls.model.Permission
import org.springframework.security.acls.model.Sid
import org.springframework.transaction.annotation.Transactional
import org.springframework.security.access.prepost.PostFilter
import org.springframework.security.access.prepost.PreAuthorize

class ContactService {

	static transactional = false

	private Random _random = new Random()

	def aclService
	def aclUtilService
	def springSecurityService

	@PreAuthorize("hasPermission(#contact, admin)")
	@Transactional
	void addPermission(Contact contact, Sid recipient, Permission permission) {
		aclUtilService.addPermission Contact, contact.id, recipient, permission
	}

	@Transactional
	@PreAuthorize("hasRole('ROLE_USER')")
	void createContact(String email, String name) {
		Contact contact = new Contact(email: email, name: name)
		contact.save()

		String username = springSecurityService.authentication.name
		// Grant the current principal administrative permission to the contact
		addPermission contact, new PrincipalSid(username), BasePermission.ADMINISTRATION

		log.debug "Created contact $contact and granted admin permission to recipient $username"
	}

	@Transactional
	@PreAuthorize("hasPermission(#contact, 'delete') or hasPermission(#contact, admin)")
	void delete(Contact contact) {
		contact.delete()

		// Delete the ACL information as well
		aclUtilService.deleteAcl contact

		log.debug "Deleted contact $contact including ACL permissions"
	}

	@Transactional
	@PreAuthorize("hasPermission(#contact, admin)")
	void deletePermission(Contact contact, Sid recipient, Permission permission) {
		def acl = aclUtilService.readAcl(contact)

		// Remove all permissions associated with this particular recipient (string equality to KISS)
		acl.entries.eachWithIndex { entry, i ->
			if (entry.sid.equals(recipient) && entry.permission.equals(permission)) {
				acl.deleteAce i
			}
		}

		aclService.updateAcl acl

		log.debug "Deleted contact $contact ACL permissions for recipient $recipient"
	}

	@PreAuthorize("hasRole('ROLE_USER')")
	@PostFilter("hasPermission(filterObject, 'read') or hasPermission(filterObject, admin)")
	List<Contact> getAll() {
		log.debug 'Returning all contacts'
		Contact.list()
	}

	@PreAuthorize("hasRole('ROLE_USER')")
	List<String> getAllRecipients() {
		log.debug 'Returning all recipients'
		User.executeQuery 'SELECT username FROM User ORDER BY username'
	}

	@PreAuthorize("hasPermission(#id, 'sample.contact.Contact', read) or hasPermission(#id, 'sample.contact.Contact', admin)")
	Contact getById(Long id) {
		log.debug "Returning contact with id: $id"
		Contact.get id
	}

	Contact getRandomContact() {
		log.debug 'Returning random contact'
		def contacts = Contact.list()
		contacts[_random.nextInt(contacts.size())]
	}

	@Transactional
	void update(Contact contact, String email, String name) {
		contact.email = email
		contact.name = name
		contact.save()
		log.debug "Updated contact $contact"
	}
}
