package sample.contact

import grails.plugins.springsecurity.Secured

@Secured(['ROLE_SUPERVISOR'])
class SuController {

	def exitUser = {}

	def switchUser = {}
}
