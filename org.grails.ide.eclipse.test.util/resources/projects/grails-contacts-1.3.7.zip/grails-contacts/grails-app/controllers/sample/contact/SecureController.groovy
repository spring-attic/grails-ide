package sample.contact

import static org.springframework.security.acls.domain.BasePermission.ADMINISTRATION
import static org.springframework.security.acls.domain.BasePermission.DELETE
import static org.springframework.security.acls.domain.BasePermission.READ
import org.springframework.security.acls.domain.PrincipalSid
import org.springframework.security.acls.model.Permission
import org.springframework.security.acls.model.Sid
import org.springframework.dao.DataAccessException

import grails.plugins.springsecurity.Secured

@Secured(['ROLE_USER'])
class SecureController {

	private static final Permission[] HAS_DELETE = [DELETE, ADMINISTRATION]
	private static final Permission[] HAS_ADMIN = [ADMINISTRATION]

	def aclPermissionFactory
	def aclUtilService
	def contactService
	def springSecurityService

	/**
	 * The index page for an authenticated user.
	 * <p>
	 * This controller displays a list of all the contacts for which the current user has read or
	 * admin permissions. It makes a call to {@link ContactService#getAll()} which automatically
	 * filters the returned list using Spring Security's ACL mechanism (see the expression annotations
	 * for the details).
	 * <p>
	 * In addition to rendering the list of contacts, the view will also include a "Del" or "Admin" link
	 * beside the contact, depending on whether the user has the corresponding permissions
	 * (admin permission is assumed to imply delete here). This information is stored in the model
	 * using the injected <code>aclUtilService</code> instance.
	 */
	def index = {
		List<Contact> myContactsList = contactService.getAll()
		Map<Contact, Boolean> hasDelete = [:]
		Map<Contact, Boolean> hasAdmin = [:]

		def currentAuth = springSecurityService.authentication
		for (Contact contact : myContactsList) {
			hasDelete[contact] = aclUtilService.hasPermission(currentAuth, contact, HAS_DELETE)
			hasAdmin[contact] = aclUtilService.hasPermission(currentAuth, contact, HAS_ADMIN)
		}

		[contacts: myContactsList,
		 hasDeletePermission: hasDelete,
		 hasAdminPermission: hasAdmin]
	}

	/**
	 * Displays the "add contact" form for GET and handles the submission of the contact form,
	 * creating a new instance if the username and email are valid.
	 */
	def add = { ContactCommand command ->

		if (!request.post) {
			return [command: new ContactCommand()]
		}

		if (command.hasErrors()) {
			return [command: command]
		}

		contactService.createContact command.email, command.name

		redirect action: index
	}

	def del = {
		Contact contact = contactService.getById(params.long('contactId'))
		contactService.delete contact
		[contact: contact]
	}

	/**
	 * Displays the permission admin page for a particular contact.
	 */
	def adminPermission = {
		Contact contact = contactService.getById(params.long('contactId'))
		[contact: contact, acl: aclUtilService.readAcl(contact)]
	}

	/**
	 * Displays the "add permission" page for a contact and
	 * handles submission of the "add permission" form.
	 */
	def addPermission = { AddPermission command ->

		if (!params.contactId) {
			flash.message = 'Contact id is required'
			redirect action: index
			return
		}

		Contact contact = contactService.getById(params.long('contactId'))

		if (!request.post) {
			return [command: new AddPermission(contact: contact),
			        recipients: contactService.allRecipients,
			        permissions: listPermissions()]
		}

		command.contact = contact

		if (command.hasErrors()) {
			return [command: command,
			        recipients: contactService.allRecipients,
			        permissions: listPermissions()]
		}

		def sid = new PrincipalSid(command.recipient)
		Permission permission = aclPermissionFactory.buildFromMask(command.permission)
		try {
			contactService.addPermission command.contact, sid, permission
		}
		catch (DataAccessException existingPermission) {
			log.error existingPermission.message, existingPermission
			command.errors.rejectValue 'recipient', 'err.recipientExistsForContact'
			return [recipients: contactService.allRecipients,
			        permissions: listPermissions()]
		}

		redirect action: index
	}

	/**
	 * Deletes a permission
	 */
	def deletePermission = {

		Contact contact = contactService.getById(params.long('contactId'))
		Sid sidObject = new PrincipalSid(params.sid)
		Permission permission = aclPermissionFactory.buildFromMask(params.int('permission'))

		contactService.deletePermission contact, sidObject, permission

		[contact: contact, sid: sidObject, permission: permission]
	}

	def debug = {
		[auth: springSecurityService.authentication]
	}

	private Map<Integer, String> listPermissions() {
		[(ADMINISTRATION.mask): g.message(code: 'select.administer'),
		 (READ.mask):           g.message(code: 'select.read'),
		 (DELETE.mask):         g.message(code: 'select.delete')]
	}
}

class ContactCommand {

	String email
	String name

	static constraints = {
		email blank: false, size: 3..50
		name blank: false, size: 3..50
	}
}

class AddPermission {

	private static final List<Integer> ADD_PERMISSIONS = [ADMINISTRATION.mask,
	                                                      READ.mask,
	                                                      DELETE.mask]
	Contact contact
	Integer permission = READ.mask
	String recipient

	static constraints = {
		permission nullable: false, inList: ADD_PERMISSIONS
		recipient blank: false, size: 1..100
	}
}
