package sample.contact

import grails.plugins.springsecurity.Secured

@Secured(['permitAll'])
class HelloController {

	def contactService

	/**
	 * The public index page, used for unauthenticated users.
	 */
	def index = {
		[contact: contactService.randomContact]
	}
}
