import sample.contact.DataSourcePopulator

class BootStrap {

	def init = { servletContext ->
		new DataSourcePopulator().populate()
	}
}
