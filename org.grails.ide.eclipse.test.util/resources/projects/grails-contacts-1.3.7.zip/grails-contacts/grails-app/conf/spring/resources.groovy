import org.springframework.security.web.access.AccessDeniedHandlerImpl

beans = {
	accessDeniedHandler(AccessDeniedHandlerImpl)
}

