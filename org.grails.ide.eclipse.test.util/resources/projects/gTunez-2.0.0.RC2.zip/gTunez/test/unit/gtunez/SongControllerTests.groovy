package gtunez



import org.junit.*
import grails.test.mixin.*
import javax.servlet.http.HttpServletResponse

@TestFor(SongController)
@Mock(Song)
class SongControllerTests {

    void testIndex() {
        controller.index()
        assert "/song/list" == response.redirectedUrl
    }

    void testList() {

        def model = controller.list()

        assert model.songInstanceList.size() == 0
        assert model.songInstanceTotal == 0
    }

    void testCreate() {
       def model = controller.create()

       assert model.songInstance != null
    }

    void testSave() {
        controller.save()
        assert response.status == HttpServletResponse.SC_METHOD_NOT_ALLOWED

        response.reset()
        request.method = 'POST'
        controller.save()

        assert model.songInstance != null
        assert view == '/song/create'

        response.reset()

        // TODO: Populate valid properties

        controller.save()

        assert response.redirectedUrl == '/song/show/1'
        assert controller.flash.message != null
        assert Song.count() == 1
    }

    void testShow() {
        controller.show()

        assert flash.message != null
        assert response.redirectedUrl == '/song/list'


        def song = new Song()

        // TODO: populate domain properties

        assert song.save() != null

        params.id = song.id

        def model = controller.show()

        assert model.songInstance == song
    }

    void testEdit() {
        controller.edit()

        assert flash.message != null
        assert response.redirectedUrl == '/song/list'


        def song = new Song()

        // TODO: populate valid domain properties

        assert song.save() != null

        params.id = song.id

        def model = controller.edit()

        assert model.songInstance == song
    }

    void testUpdate() {

        controller.update()
        assert response.status == HttpServletResponse.SC_METHOD_NOT_ALLOWED

        response.reset()
        request.method = 'POST'
        controller.update()

        assert flash.message != null
        assert response.redirectedUrl == '/song/list'

        response.reset()


        def song = new Song()

        // TODO: populate valid domain properties

        assert song.save() != null

        // test invalid parameters in update
        params.id = song.id

        controller.update()

        assert view == "/song/edit"
        assert model.songInstance != null

        song.clearErrors()

        // TODO: populate valid domain form parameter
        controller.update()

        assert response.redirectedUrl == "/song/show/$song.id"
        assert flash.message != null
    }

    void testDelete() {
        controller.delete()
        assert response.status == HttpServletResponse.SC_METHOD_NOT_ALLOWED

        response.reset()
        request.method = 'POST'
        controller.delete()
        assert flash.message != null
        assert response.redirectedUrl == '/song/list'

        response.reset()

        def song = new Song()

        // TODO: populate valid domain properties
        assert song.save() != null
        assert Song.count() == 1

        params.id = song.id

        controller.delete()

        assert Song.count() == 0
        assert Song.get(song.id) == null
        assert response.redirectedUrl == '/song/list'
    }
}
