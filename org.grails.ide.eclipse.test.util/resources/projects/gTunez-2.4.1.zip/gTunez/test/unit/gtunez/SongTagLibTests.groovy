package gtunez



import grails.test.mixin.*
import org.junit.*

/**
 * See the API for {@link grails.test.mixin.web.GroovyPageUnitTestMixin} for usage instructions
 */
@TestFor(SongTagLib)
class SongTagLibTests {

    void testSomething() {
        fail "Implement me"
    }
}
