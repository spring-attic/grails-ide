package gtunes

class Song {

    static constraints = {
    }
	
	String title
	String artist

}
