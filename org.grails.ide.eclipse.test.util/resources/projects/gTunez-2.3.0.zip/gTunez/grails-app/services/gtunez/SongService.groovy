package gtunez

class SongService {

    static transactional = true
	
	def start() {
		println "Starting ${SongService.class.getSimpleName()}"
	}

    def stop() {
		println "Starting ${SongService.class.getSimpleName()}"
    } 
	
    def play(Song track) {
		println "Playing... ${track.title}"
    }
}