class BootStrap {

	def songService

    def init = { servletContext ->
		songService.start()
    }
    def destroy = {
		songService.stop()
    }
}