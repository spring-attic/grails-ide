class TinyurlService {

    boolean transactional = true

	String tiny(url) {
		return new URL("http://tinyurl.com/api-create.php?url=${url.encodeAsURL()}").text
	}
}
