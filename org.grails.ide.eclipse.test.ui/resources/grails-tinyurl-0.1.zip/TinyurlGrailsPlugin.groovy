class TinyurlGrailsPlugin {

    def version = "0.1"
    def grailsVersion = "1.1 > *"
    def dependsOn = [:]

    def pluginExcludes = [
            "grails-app/views/error.gsp",
			"grails-app/conf/UrlMappings.groovy",
			"grails-app/conf/DataSource.groovy"
    ]

    def author = "Lucas Teixeira"
    def authorEmail = "lucastex@gmail.com"
    def title = "TinyUrl Plugin"
    def description = "Easy creation of urls shrinked by TinyUrl"

    def documentation = "http://www.grails.org/plugin/TinyUrl"
}
